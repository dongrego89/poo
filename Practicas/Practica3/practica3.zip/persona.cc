/*
 * persona.cc
 *
 *  Created on: 22/12/2014
 *      Author: grego
 */




